# name = input("What's your name, Sir?")
# print("Hello", name)
number = int(input("give us a number. What number?"))
if number > 10:
  print("This number is greater than 10")
elif number < 10:
  print("This number is less than 10")
else:
  print("number = 10")