$(document).ready(function(){
  $("#giraffe").click(function(){
    $("#giraffe").slideDown("slow");
  });
});