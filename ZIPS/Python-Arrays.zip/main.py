import numpy
my_list = ["pizza", "grilled cheese", "meatballs"]
my_array = numpy.array(my_list)

print(my_array)
sliced_array = my_array[:4]
print(sliced_array)
print(my_array[0])
print(my_array[1])
print(my_array[2])