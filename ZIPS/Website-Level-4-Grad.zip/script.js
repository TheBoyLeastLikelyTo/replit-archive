def buttonClick()

function buttonClick() {
  if (validate()) {
    alert("RAINBOW");
  }
}